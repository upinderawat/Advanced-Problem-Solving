#include <iostream>
#include <cstring>
#include <stdlib.h>
#include <cmath>
#include "queue.h"
int main(int argc, char const *argv[])
{
    /* code */
 //   queue myq(11,2);
    queue myq;
    myq.push_back(3);
    myq.push_back(4);
    myq.push_back(5);
    myq.push_back(6);
    myq.push_back(7);
    myq.push_back(8);
    myq.push_back(9);
    myq.push_back(10);
    myq.push_back(11);
    // myq.traverse();
    // std::cout<<"\n";
    std::cout<<"Size: "<<myq.size()<<"\n";
    // myq.resize(2);
//    myq.clear();
//    myq.info();
    for(int i=0; i<myq.size(); i++)
       std::cout<<myq[i]<<" ";
    // // std::cout<<myq.pop_back()<<"\n";
    // std::cout<<myq.pop_back()<<"\n";
    
    // // myq.push_back(7);
    // myq.push_back(8);
 
     myq.push_front(1);
    myq.push_front(0);
    // myq.push_back(7);
    std::cout<<"\nTraversal after 2 front push: ";
    myq.traverse();
    // std::cout<<"\n";
    std::cout<<"Back: "<<myq.back()<<"\n";
    std::cout<<"Front: "<<myq.front()<<"\n";
    
    
    std::cout<<"Popped:"<<myq.pop_back()<<"\n";
    // myq.traverse();
    // std::cout<<"\n";
        for(int i=0; i<myq.size(); i++)
       std::cout<<myq[i]<<" ";
 
  //std::cout<<"Element at back"<<myq.back()<<"\n";
    //std::cout<<myq.pop_back()<<"\n";
    //std::cout<<myq.pop_back()<<"\n";
//  std::cout<<"Element at back"<<myq.back()<<"\n";
    
    // std::cout<<myq.pop_back()<<"\n";
    // std::cout<<myq.pop_back()<<"\n";
//  std::cout<<"Element at back"<<myq.back()<<"\n";
    
//    myq.traverse();
    return 0;
}