#ifndef QUEUE
#define QUEUE
#define max_buff_size 2
#define initial_size  1

class queue{
private:
    int **q;
    int top_i, rear_i;//index into fixed buff of dynamic arr
    int top, rear;//index into dynamic arr
    int curr_size = initial_size;
public:
    queue(){
        top = top_i = 0;
        rear = rear_i = -1;
        int *temp = (int *)malloc(sizeof(int)*max_buff_size);
        q = (int **)malloc(sizeof(int*)*curr_size);
        q[++rear] = temp;
    }
    queue(int N, int x){
        top = top_i = 0;
        rear = -1;
        int *temp = nullptr;
        int fixedBlocks = ceil(N/(max_buff_size*1.0));
        q = (int **)malloc(sizeof(int*)*fixedBlocks);
        curr_size = fixedBlocks;
        while(fixedBlocks--){
            temp = (int *)malloc(sizeof(int)*max_buff_size);
            q[++rear] = temp;
        }
        rear_i = (N-1) % max_buff_size;
        traverse_and_set(x);
    }
    int info(){
        std::cout<<"curr_size: "<<curr_size<<"\n";
        std::cout<<"top: "<<top<<"\n";
        std::cout<<"top_i: "<<top_i<<"\n";
        std::cout<<"rear: "<<rear<<"\n";
        std::cout<<"rear_i: "<<rear_i<<"\n";
    }
    bool empty(){
        return this->size() > 0 ? true: false;
    }
    int size(){
        int len = (rear - top -1)*max_buff_size;
        len += rear_i + 1;
        len +=max_buff_size- top_i;
        return len;
    }
    int operator[](int idx){
        return *(q[(idx/max_buff_size + top)] + (top_i + idx%max_buff_size));
    }
    //realloc mem by increasing/decreasing by given size and updates curr_size
    void resize(int);
    void shiftByN(int);
    void push_back(int);
    void push_front(int);
    int pop_front();
    int pop_back();
    int front();
    int back();
    void traverse(){
        int i,j;
        for(i= top; i<=rear; i++){
            if(i== top){
                j = top_i;
            }
            else{
                j = 0;
            }
            if(i != rear){
                for(; j< max_buff_size; j++){
                    std::cout<<*(q[i]+j)<<" ";
                }
            }else{
                for(;j<= rear_i; j++){
                    std::cout<<*(q[i]+j)<<" ";
                }
            }
        }
    }
    void traverse_and_set(int val){
        int i,j;
        for(i= top; i<=rear; i++){
            if(i== top){
                j = top_i;
            }
            else{
                j = 0;
            }
            if(i != rear){
                for(; j< max_buff_size; j++){
                    *(q[i]+j) = val;
                }
            }else{
                for(;j<= rear_i; j++){
                    *(q[i]+j)= val;
                }
            }
        }
    }
};

void queue:: resize(int new_size){
        int fixedBlocks = new_size - curr_size;
        q = (int **)realloc(q, sizeof(int*)*new_size);
        int i=rear;
        while(fixedBlocks--){   
            int * temp = (int*)malloc(sizeof(int)*max_buff_size);
            q[++i] = temp;
        }
        rear++;
//      std::cout<<"New Size:"<<new_size<<"\n";
        curr_size = new_size; 
}

void queue:: push_back(int val){//rear points to last stored loc
    if(rear_i < max_buff_size-1){
        rear_i++; 
        *(q[rear]+rear_i)= val;
    }
    else{
        if(rear < curr_size-1){
            rear++;
        }
        else{
//            std::cout<<"mem gained\n";
            resize(curr_size*2);
        }
        rear_i = 0;
        *(q[rear] + rear_i) = val;
    }
}
void queue::push_front(int val){
    if(top_i > 0){
        top_i--;
        *(q[top]+top_i) =val;
    }else{//top_i is 0
        
        if(top > 0){
            top--;
            top_i = max_buff_size-1;
            *(q[top] + top_i) = val;
        }
        else{//top is 0
            shiftByN(1);
            top--;
            top_i = max_buff_size-1;
            *(q[top] + top_i) = val;
        }
    }
}
void queue::shiftByN(int shifts){//shift N to be be implemented 
    if(rear >= curr_size-2)
        resize(curr_size*2);//max(curr_size+shift, curr_size*2) check this shifts > curr_size
    else
        rear++;
    for(int i = rear; i>= top; i--){
        q[i+shifts] = q[i];
    }
    //change the pointer to new loc instead of prev
    q[top] = (int*)malloc(sizeof(int)*max_buff_size);
    //rear += shifts;
    top+= shifts;
}

int queue::pop_front(){
    int temp = *(q[top] + top_i);
    if(top_i < max_buff_size-1){
        top_i++;
    }
    else{//top_i == max_buff_size-1
        free(q[top]);
        curr_size--;
        top++;
        top_i = 0;
    }
    return temp;
}
int queue::pop_back(){
    // if(top == rear && top_i == rear_i){
    //     //To Do: need to throw exception
    //     std::cout<<"Empty deque\n";
    //     return -1;
    // }
    int temp = *(q[rear] + rear_i);

    if(rear_i > 0){
        rear_i--;
    }else{
       // std::cout<<"Mem freed at rear: "<<rear<<"\n";
        free(q[rear]);
        curr_size--;
        rear--;
        rear_i = max_buff_size - 1;
    }
    return temp;
}

int queue::front(){
    return *(q[top]+top_i);
}
int queue::back(){
    //To do: error handling emty check
    return *(q[rear]+rear_i);
}
#endif