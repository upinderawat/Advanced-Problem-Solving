#include <bits/stdc++.h>
#define ll long long
using namespace std;

template<class K, class V>
class LRUCache {
	unsigned long long qsize;
	list<pair<K, V> > queue;
	unordered_map<K , typename list<pair<K, V>>::iterator> mymap;
public:
    LRUCache(ll capacity) {
    	qsize = capacity;
    }
    
    pair<bool, V> get(K key) {
        if(mymap.find(key) != mymap.end()){
        	//if found
        	auto it = mymap[key];
        	V val = it->second;
        	queue.erase(it);
        	queue.push_front({key, val});
        	mymap[key] = queue.begin();
        	return {true, val};
        }
        else{//if not found
			return {false, -1};	
        }
    }
    
    void set(K key, V val) {
        K old_k;
        if(mymap.find(key) != mymap.end()){
			auto it = mymap[key];
			queue.erase(it);
			mymap.erase(key);
        }
        else{//if not found
        	if(queue.size() >= qsize){//frame size exceeds
        		old_k = queue.back().first;
        		queue.pop_back();
        		mymap.erase(old_k);
        	}
        }
		queue.push_front({key, val});
		mymap[key] = queue.begin();
    }
};
template<class K, class V>
void fn(ll &qsize){
	ll t;
	char q;
//	cout<<"Input T:";
	cin>>t;
	LRUCache<K, V> queue(qsize);
	K key;
	V val;
	while(t--){
		cin>>q;
		switch(q){
			case 'S':
				cin>>key>>val;
				queue.set(key, val);
			break;
			case 'G':
				cin>>key;
				auto it = queue.get(key);
				
				if(it.first){
					cout<<it.second<<"\n";
				}
				else
					cout<<"-1"<<"\n";
			break;
			cout<<"Input Format S <key> <value> | G <key>\n";
		}
	}
}
int main(int argc, char const *argv[]){
	// if(argc <= 1){
	// 	cout<<"--missing 1 parameter: ./a.out <sizeof(queue)>\n";
	// 	exit(-1);
	// }
	
	ll qsize ;//= stoi(argv[1]);	
	//modify the type here
	cin>>qsize;
	fn<ll, ll>(qsize);
	return 0;
}