#include<iostream>
#include<string>
#include <algorithm>	
#include <cstring>
#define ll long long

void trim_zeros(std::string &res){
	ll i;
	for(i=res.size()-1; i >=0 && res.compare(i,1,"0") == 0 ; i--);
	if(i<0)
		res = "0";
	else
		res.erase(i+1,res.size()-i-1);
}

class BigInt{
	private:
		std::string __int;
		int sign;//1 is -ve
	public:
		BigInt():__int("0"), sign(0){};
		//reverse and store for ease of computation 
		BigInt(std::string __int){
			std::string s="";
			sign = __int.compare(0, 1, "-")==0 ? 1 : 0;	
			//append number in reverse excl. '-' if present
			for(ll i=__int.size(); i> sign; i--){
				s = s + __int[i-1];
			}
			trim_zeros(s);
			this->__int = s;
		}
		void set_sign(int sign){
			this->sign = sign;
		}
		void set_str(std::string s){
			this->__int = s;
		}
		int get_sign(){
			return sign;
		}
		std::string get_str(){
			return __int;
		}
		unsigned ll size(){
			return this->get_str().size();
		} 

		BigInt operator + (BigInt &b);
		std::string addBigInt(BigInt &a, BigInt &b);
		
		BigInt operator - (BigInt &b);
		std::string minusBigInt(BigInt &a, BigInt &b);
		
		BigInt operator * (BigInt &b);
		BigInt multiplyBigInt(BigInt &a, BigInt &b);

		BigInt operator / (BigInt &b);
		BigInt divideBigInt(BigInt &a, BigInt &b);

		void operator +=(BigInt b);
		void operator -=(BigInt b);	

		bool operator < (BigInt &b);
		bool abs_less(BigInt a, BigInt b);
		//bool operator >(BigInt &b);
		bool operator == (BigInt &b);
		bool abs_equal(BigInt a, BigInt b);
		//reverse and print
		friend std::ostream &operator<<(std::ostream &fout,  BigInt &a ) { 
			std::string c="";
			unsigned ll sizeA = a.size();
			std::string a_str= a.get_str();
			for(ll i=0; i<sizeA; i++){
				c = a_str[i] + c;
			}			
			//append sign if any
			c = (a.get_sign() == 1)? "-" + c : c;
			fout<<c;
			return fout;            
      	}
};
BigInt BigInt:: operator + (BigInt &b){
	std::string res;
	BigInt a = *this;
	BigInt c;
	if(a.get_sign() == b.get_sign()){
		res = addBigInt(a, b);
		(a.get_sign()== 0) ? c.set_sign(0): c.set_sign(1);
	}
	else{//compare the abs magnitude to decide sign
		if(abs_less(a, b)){
			res = minusBigInt(b, a);
			c.set_sign(b.get_sign());
		}
		else{
			res = minusBigInt(a, b);
			c.set_sign(a.get_sign());
		}
	}
	c.set_str(res);
	return c;
}

//Utility fn() ignores
std::string BigInt::addBigInt(BigInt &a, BigInt &b){
	std::string res="";
	std::string s1 = a.get_str();
	std::string s2 = b.get_str();
	ll sizeA = s1.size();
	ll sizeB = s2.size();
	ll i, temp, carry=0;

	for(i=0; i < std::min(sizeA, sizeB); i++){
		temp = (s1[i] - '0') + (s2[i] - '0') + carry;
		carry = temp/10;
		res = res + std::to_string(temp%10);
	}
	while(i<sizeA){//either of the while will execute
		temp = (s1[i++]-'0' + carry);
		carry = temp/10;
		res = res + std::to_string(temp%10);
	}
	while(i<sizeB){
		temp = (s2[i++] - '0' + carry);
		carry = temp/10;
		res = res + std::to_string(temp%10);
	}
	//append 1 in case of any carry
	carry == 1? res+="1":res;
	//avoid calling constructor as it will reverse the result
	return res;
}

BigInt BigInt::operator -(BigInt &b){
	std::string res;
	BigInt c;
	BigInt a = *this;
	if(a.get_sign() == b.get_sign()){//both are same sign
		if(a.get_sign() == 0){//and are positive
			if(abs_less(a, b)){
				res = minusBigInt(b, a);
				c.set_sign(1);
			}
			else{
				res = minusBigInt(a, b);
				c.set_sign(0);
			}
		}
		else{//both are negative
			if(abs_less(a, b)){
				res = minusBigInt(b, a);
				c.set_sign(0);
			}
			else{
				res = minusBigInt(a, b);
				c.set_sign(1);
			}
		}
	}
	else{//both are opp sign
		if(a.get_sign() == 0){//a is positive, b is negative
			res = addBigInt(a, b);
			c.set_sign(0);
		
		}
		else{//a is negative, b is positive
			res = addBigInt(a, b);
			c.set_sign(1);
		}
	}
	trim_zeros(res);
	c.set_str(res);
	return c;
}

//utility fn() ignores sign, assumes a>b
std::string BigInt::minusBigInt(BigInt &a, BigInt &b){
	std::string s1 = a.get_str();
	std::string s2 = b.get_str();
	ll sizeA = s1.size();
	ll sizeB = s2.size();
	std::string res="";
	ll i, temp, borrow=0;

	//assume s1 > s2

	for(i=0; i < std::min(sizeA, sizeB); i++){
		temp = (s1[i] - '0') - (s2[i] - '0') - borrow;
		if(temp < 0){
			temp += 10;
			borrow = 1;
		}
		else{
			borrow = 0;
		}
		res = res + std::to_string(temp);
	}
	while(i<sizeA){//either of the while will execute
		temp = (s1[i++]-'0' - borrow);
		if(temp < 0){
			temp += 10;
			borrow = 1;
		}
		else
			borrow = 0;
		res = res + std::to_string(temp);
	}
	while(i<sizeB){
		temp = (s2[i++]-'0' - borrow);
		if(temp < 0){
			temp += 10;
			borrow = 1;
		}
		else
			borrow = 0;
		res = res + std::to_string(temp);
	}
	return res;
}
//optimized multiplication in log(n)
BigInt BigInt::multiplyBigInt(BigInt &a, BigInt &b){
	BigInt res= a;//initialize res to 0
	BigInt i("1");
	for(; abs_less(i + i, b) || abs_equal(i+i, b); i += i, res += res);
		
	for(; abs_less(i, b); i += BigInt("1"), res += a);
	return res;
}
BigInt BigInt::operator *(BigInt &b){
	BigInt a = *this;
	BigInt c;
	if(!(a == c || b == c)){// a and b are both non zero
		c = multiplyBigInt(a, b);
		if(a.get_sign() == b.get_sign())
			c.set_sign(0);
		else
			c.set_sign(1);
	}
	return c;
}

BigInt BigInt::divideBigInt(BigInt &a, BigInt &b){
	BigInt res;
	for(BigInt i=a; !(abs_less(i, b)); i -= b, res += BigInt("1"));
	return res;
}
BigInt BigInt::operator / (BigInt &b){
	BigInt a = *this;
	BigInt c;
	c = divideBigInt(a, b);
	if(a.get_sign() == b.get_sign())
		c.set_sign(0);
	else
		c.set_sign(1);
	return c;
}


void BigInt::operator +=(BigInt b){
	*this = *this + b;
}

void BigInt::operator -=(BigInt b){
	*this = *this - b;
}

bool BigInt::operator <(BigInt &b){
	BigInt a = *this;
	bool a_less_than_b = abs_less(a, b);
	if(a.get_sign() == b.get_sign()){//both have same sign
		if(a.get_sign()==0)
			return a_less_than_b;
		else
			return !a_less_than_b;
	}else{//if both have opposite sign
		//if first is negative
		return (a.get_sign() == 1)? true: false;
	}
} 

bool BigInt::abs_less(BigInt a, BigInt b){
		std::string s1 = a.get_str();
		std::string s2 = b.get_str();
		reverse(s1.begin(), s1.end());
		reverse(s2.begin(), s2.end());
		if(s1.size() == s2.size()){//and have same size
			return (strcmp(s1.c_str(), s2.c_str()) < 0)? true:false;
		}//and size is diff
		else{
			if(s1.size() < s2.size())
				return true;
			else
				return false;
		}
}

bool BigInt::operator == (BigInt &b){
	BigInt a = *this;
	bool a_equal_than_b = abs_equal(a, b);
	return (a.get_sign() == b.get_sign()) ? a_equal_than_b : false;
}

bool BigInt::abs_equal(BigInt a, BigInt b){
	std::string s1 = a.get_str();
	std::string s2 = b.get_str();
	if(s1.size() == s2.size()){//and have same size
		return (strcmp(s1.c_str(), s2.c_str()) == 0)? true:false;
	}//and size is diff
	else{
		return false;
	}
}
// -------end of class methods-----
BigInt BigInt_gcd(BigInt a, BigInt b){ 
    
    while (!(a == b)){   
    	if (a < b)         
            b = b - a;         
        else        
            a = a - b;         
    } 
    return a; 
}
bool isEven(BigInt &a){
	std::string str_a = a.get_str();
	if(    str_a.compare(0, 1, "0") == 0 
		|| str_a.compare(0, 1, "2") == 0 
		|| str_a.compare(0, 1, "4") == 0 
		|| str_a.compare(0, 1, "6") == 0 
		|| str_a.compare(0, 1, "8") == 0 ){
		return true;
	}
	else
		return false;
}
BigInt pow(BigInt a, BigInt b){
	//works only for positive power of b
	BigInt res("1");
	BigInt zero("0");
	BigInt two("2");
	while(! (b < zero || b == zero ) ){
		if(!isEven(b)){
			res = res * a;
		}
		a = a * a;
		b = b / two;
	}		
	return res;
}

BigInt fact(BigInt a){
	BigInt res("1");
	for(BigInt i("1"); i < a || i == a; i += BigInt("1")){
		res = res * i ;
	}
	return res;
}

int main(int argc, char const *argv[])
{
	BigInt c;
	BigInt a("6");
	BigInt b("100");
//	c=BigInt_gcd(BigInt("156325"),BigInt("241834775"));	
//	std::cout<<c<<"\n";

//	c = pow(a,b);
	//c = a*b;
	//c = a /b;
	c = fact(b);
	std::cout<<c<<"\n";
//	std::cout<<c;
	return 0;
}